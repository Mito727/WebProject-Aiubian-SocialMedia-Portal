Its a web application.
-------------------------

This is an application where all the AIUBian like AIUB Faculty, Student and Alumni will be connected together. 
So that, one AIUBian can help another AIUBian. A teacher or alumni will see the current students profile .
Teacher or Alumni can forward a Student  to company. 
Or an alumni can post which is a job offer and current student will know in short time.
A students also see the faculty profile so that students can get an idea which faculty will work which thesis domain. 
Any user can add their other social accounts like LinkedIn, Github etc. They can edit their profile through crud operation. 
They can change their profile picture. 
They can see different posts also can filter it in different section like Faculty post, Student post, Alumni post.
