<?php

    echo "Hello Php Folder.Its an Layer Architecture Views";
?>